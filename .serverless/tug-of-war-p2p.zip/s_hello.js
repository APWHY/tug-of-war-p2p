
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'apwhy',
  applicationName: 'tug-of-war-pp',
  appUid: 'DyzlR1cZy95mhb6s1R',
  orgUid: 'C9Hs95gFF2YMKBcdmf',
  deploymentUid: 'deaa1c2c-0004-4386-ba83-d826f46f38d7',
  serviceName: 'tug-of-war-p2p',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tug-of-war-p2p-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}